package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.entity.Kh;
import com.entity.Dd;
import com.entity.Sp;
import com.util.DBhelper;

public class DdDao {

	// ���Ӷ���
	public int add(Dd sfxx) {
		int n = 0;
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			con = DBhelper.getCon();
			ps = con.prepareStatement("insert into dd values(?,?,?,now(),?,?)");
			ps.setString(1, sfxx.getDdbh());
			ps.setString(2, sfxx.getSjbh());
			ps.setString(3, sfxx.getKhbh());
			ps.setInt(4, sfxx.getGmsl());
			ps.setFloat(5, sfxx.getGmjg());
			n = ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBhelper.myClose(con, ps, rs);
		}

		return n;
	}

	// ɾ������
	public int delete(String ddbh) {
		int n = 0;
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			con = DBhelper.getCon();
			ps = con.prepareStatement("delete from dd where ddbh="+ddbh);
			n = ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBhelper.myClose(con, ps, rs);
		}

		return n;
	}

	// ��ѯ���м�¼
	public List<Dd> getAll() {
		List<Dd> myl = new ArrayList<Dd>();
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			con = DBhelper.getCon();
			ps = con.prepareStatement("select * from dd");
			rs = ps.executeQuery();
			while (rs.next()) {
				Dd sfxx = new Dd();
				sfxx.setDdbh(rs.getString(1));
				sfxx.setSjbh(rs.getString(2));
				sfxx.setKhbh(rs.getString(3));
				sfxx.setGmsj(rs.getDate(4));
				sfxx.setGmsl(rs.getInt(5));
				sfxx.setGmjg(rs.getFloat(6));
				myl.add(sfxx);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBhelper.myClose(con, ps, rs);
		}
		return myl;
	}
	
	public float getYyea() {
		float myl = 0;
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			con = DBhelper.getCon();
			ps = con.prepareStatement("select sum(gmjg) from dd where month(gmsj)=month(now())");
			rs = ps.executeQuery();
			if (rs.next()) {
				myl=rs.getFloat(1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBhelper.myClose(con, ps, rs);
		}
		return myl;
	}
	
	public float getYyec() {
		float myl = 0;
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			con = DBhelper.getCon();
			ps = con.prepareStatement("select sum(gmjg) from dd where year(gmsj)=year(now())");
			rs = ps.executeQuery();
			if (rs.next()) {
				myl=rs.getFloat(1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBhelper.myClose(con, ps, rs);
		}
		return myl;
	}
	
	public float getYyeb() {
		float myl = 0;
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			con = DBhelper.getCon();
			ps = con.prepareStatement("select sum(gmjg) from dd where gmsj=date_format(now(),'%Y-%m-%d')");
			rs = ps.executeQuery();
			if (rs.next()) {
				myl=rs.getFloat(1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBhelper.myClose(con, ps, rs);
		}
		return myl;
	}

	// ��ѯ���м�¼
	public List<Dd> getAll(String khbh) {
		List<Dd> myl = new ArrayList<Dd>();
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			con = DBhelper.getCon();
			ps = con.prepareStatement("select * from dd where khbh=" + khbh);
			rs = ps.executeQuery();
			while (rs.next()) {
				Dd sfxx = new Dd();
				sfxx.setDdbh(rs.getString(1));
				sfxx.setSjbh(rs.getString(2));
				sfxx.setKhbh(rs.getString(3));
				sfxx.setGmsj(rs.getDate(4));
				sfxx.setGmsl(rs.getInt(5));
				sfxx.setGmjg(rs.getFloat(6));
				myl.add(sfxx);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBhelper.myClose(con, ps, rs);
		}
		return myl;
	}

}
