package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.entity.Kh;
import com.entity.Sp;
import com.util.DBhelper;

public class KhDao {

	// �޸ķ���
	public int update(Kh fk) {
		int n = 0;
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			con = DBhelper.getCon();
			ps = con.prepareStatement("update kh set xm=? , xb=? , nl=? , lxfs=? , shdz=? , mm=? where khbh=" + fk.getKhbh());
			ps.setString(1, fk.getXm());
			ps.setString(2, fk.getXb());
			ps.setString(3, fk.getNl());
			ps.setString(4, fk.getLxfs());
			ps.setString(5, fk.getShdz());
			ps.setString(6, fk.getMm());
			n = ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBhelper.myClose(con, ps, rs);
		}

		return n;
	}

	// ɾ������
	public int delete(String fkbh) {
		int n = 0;
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			con = DBhelper.getCon();
			ps = con.prepareStatement("delete from kh where khbh=" + fkbh);
			n = ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBhelper.myClose(con, ps, rs);
		}

		return n;
	}

	// ���ӷ���
	public int add(Kh fk) {
		int n = 0;
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			con = DBhelper.getCon();
			ps = con.prepareStatement("insert into kh values(?,?,?,?,?,?,?)");
			ps.setString(1, fk.getKhbh());
			ps.setString(2, fk.getXm());
			ps.setString(3, fk.getXb());
			ps.setString(4, fk.getNl());
			ps.setString(5, fk.getLxfs());
			ps.setString(6, fk.getShdz());
			ps.setString(7, fk.getMm());
			n = ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBhelper.myClose(con, ps, rs);
		}

		return n;
	}

	// ������������ѯ
	public List<Kh> getAll(String str) {
		List<Kh> ss = new ArrayList<Kh>();
		ResultSet rs = null;
		PreparedStatement ps = null;
		Connection con = null;
		try {
			con = DBhelper.getCon();
			ps = con.prepareStatement("select * from kh where xm like '%" + str + "%'");
			rs = ps.executeQuery();
			while (rs.next()) {
				Kh ta = new Kh();
				ta.setKhbh(rs.getString(1));
				ta.setXm(rs.getString(2));
				ta.setXb(rs.getString(3));
				ta.setNl(rs.getString(4));
				ta.setLxfs(rs.getString(5));
				ta.setShdz(rs.getString(6));
				ta.setMm(rs.getString(7));
				ss.add(ta);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBhelper.myClose(con, ps, rs);
		}
		return ss;
	}

	// ������������ѯ����
	public Kh getOne(String fkbh) {
		ResultSet rs = null;
		PreparedStatement ps = null;
		Connection con = null;
		Kh ta = new Kh();
		try {
			con = DBhelper.getCon();
			ps = con.prepareStatement("select * from kh where khbh=" + fkbh);
			rs = ps.executeQuery();
			while (rs.next()) {
				ta.setKhbh(rs.getString(1));
				ta.setXm(rs.getString(2));
				ta.setXb(rs.getString(3));
				ta.setNl(rs.getString(4));
				ta.setLxfs(rs.getString(5));
				ta.setShdz(rs.getString(6));
				ta.setMm(rs.getString(7));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBhelper.myClose(con, ps, rs);
		}
		return ta;
	}

	// ��½
	public String login(String fkxm, String fkmm) {
		ResultSet rs = null;
		PreparedStatement ps = null;
		Connection con = null;
		String fkbh = "";
		try {
			con = DBhelper.getCon();
			ps = con.prepareStatement("select * from kh where xm like '" + fkxm + "' and mm like '" + fkmm + "'");
			rs = ps.executeQuery();
			while (rs.next()) {
				fkbh = rs.getString(1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBhelper.myClose(con, ps, rs);
		}
		return fkbh;
	}

}
