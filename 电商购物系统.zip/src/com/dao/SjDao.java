package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.entity.Kh;
import com.entity.Sj;
import com.util.DBhelper;

public class SjDao {

	// ��½
	public Sj check(String name, String pwd) {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		Sj ta=new Sj();
		try {
			con = DBhelper.getCon();
			ps = con.prepareStatement("select * from sj where mc = ? and mm = ?");
			ps.setString(1, name);
			ps.setString(2, pwd);
			rs = ps.executeQuery();
			while (rs.next()) {
				ta.setSjbh(rs.getString(1));
				ta.setMc(rs.getString(2));
				ta.setDz(rs.getString(3));
				ta.setFzr(rs.getString(4));
				ta.setLxfs(rs.getString(5));
				ta.setMm(rs.getString(6));
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		} finally {
			DBhelper.myClose(con, ps, rs);
		}
		return ta;
	}

	// ������������ѯ
	public List<Sj> getAll(String str) {
		List<Sj> ss = new ArrayList<Sj>();
		ResultSet rs = null;
		PreparedStatement ps = null;
		Connection con = null;
		try {
			con = DBhelper.getCon();
			ps = con.prepareStatement("select * from sj where mc like '%" + str + "%'");
			rs = ps.executeQuery();
			while (rs.next()) {
				Sj ta = new Sj();
				ta.setSjbh(rs.getString(1));
				ta.setMc(rs.getString(2));
				ta.setDz(rs.getString(3));
				ta.setFzr(rs.getString(4));
				ta.setLxfs(rs.getString(5));
				ta.setMm(rs.getString(6));
				ss.add(ta);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBhelper.myClose(con, ps, rs);
		}
		return ss;
	}

}
