package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

import com.entity.Kh;
import com.entity.Sp;
import com.util.DBhelper;

public class SpDao {

	// ��ѯ����
	public Sp selectOne(String fwbh) {
		Sp u = new Sp();
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			con = DBhelper.getCon();
			ps = con.prepareStatement("select * from sp where spbh=" + fwbh);
			rs = ps.executeQuery();
			if (rs.next()) {
				u.setSpbh(rs.getString(1));
				u.setSpmc(rs.getString(2));
				u.setSpsl(rs.getInt(3));
				u.setSpjg(rs.getFloat(4));
				u.setSpxxms(rs.getString(5));
				u.setSjbh(rs.getString(6));
				u.setImg(rs.getString(7));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBhelper.myClose(con, ps, rs);
		}

		return u;
	}

	// ��ѯ���еķ���
	public List<Sp> getAll(String str) {
		List<Sp> mys = new ArrayList<Sp>();
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			con = DBhelper.getCon();
			ps = con.prepareStatement("select * from sp where spmc like '%" + str + "%'");
			rs = ps.executeQuery();
			while (rs.next()) {
				Sp u = new Sp();
				u.setSpbh(rs.getString(1));
				u.setSpmc(rs.getString(2));
				u.setSpsl(rs.getInt(3));
				u.setSpjg(rs.getFloat(4));
				u.setSpxxms(rs.getString(5));
				u.setSjbh(rs.getString(6));
				u.setImg(rs.getString(7));
				mys.add(u);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBhelper.myClose(con, ps, rs);
		}

		return mys;
	}
	
	// ��ѯ���еķ���
	public int getFwsl() {
		int mys = 0;
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			con = DBhelper.getCon();
			ps = con.prepareStatement("select count(*) from sp");
			rs = ps.executeQuery();
			if (rs.next()) {
				mys=rs.getInt(1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBhelper.myClose(con, ps, rs);
		}

		return mys;
	}

	// �޸�
	public int update(Sp fw) {
		int n = 0;
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			con = DBhelper.getCon();
			ps = con.prepareStatement(
					"update sp set spmc=?,spsl=?,spjg=?,spxxms=?,sjbh=?,img=? where spbh=" + fw.getSpbh());
			ps.setString(1, fw.getSpmc());
			ps.setInt(2, fw.getSpsl());
			ps.setFloat(3, fw.getSpjg());
			ps.setString(4, fw.getSpxxms());
			ps.setString(5, fw.getSjbh());
			ps.setString(6, fw.getImg());
			n = ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBhelper.myClose(con, ps, rs);
		}

		return n;
	}
	
	// ����
	public int Add(Sp fw) {
		int n = 0;
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			con = DBhelper.getCon();
			ps = con.prepareStatement(
					"insert into sp values(?,?,?,?,?,?,?)");
			ps.setString(1, fw.getSpbh());
			ps.setString(2, fw.getSpmc());
			ps.setInt(3, fw.getSpsl());
			ps.setFloat(4, fw.getSpjg());
			ps.setString(5, fw.getSpxxms());
			ps.setString(6, fw.getSjbh());
			ps.setString(7, fw.getImg());
			n = ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBhelper.myClose(con, ps, rs);
		}

		return n;
	}

	// ɾ��
	public int delete(String fwbh) {
		int n = 0;
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			con = DBhelper.getCon();
			ps = con.prepareStatement("delete from sp where spbh like " + fwbh);
			n = ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBhelper.myClose(con, ps, rs);
		}

		return n;
	}

}
