package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.entity.Kh;
import com.entity.Dd;
import com.entity.Sp;
import com.entity.Gwc;
import com.util.DBhelper;

public class GwcDao {

	// �����ղ�
	public int add(Gwc gwc) {
		int n = 0;
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			con = DBhelper.getCon();
			ps = con.prepareStatement("insert into gwc values(?,?,now(),?)");
			ps.setString(1, gwc.getSpbh());
			ps.setString(2, gwc.getKhbh());
			ps.setInt(3, gwc.getJgsl());
			n = ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBhelper.myClose(con, ps, rs);
		}

		return n;
	}

	// ɾ���ղ�
	public int delete(String fwbh) {
		int n = 0;
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			con = DBhelper.getCon();
			ps = con.prepareStatement("delete from gwc where spbh="+fwbh);
			n = ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBhelper.myClose(con, ps, rs);
		}

		return n;
	}

	// ��ѯ���м�¼
	public List<Sp> getAll(String fkbh) {
		List<Sp> myl = new ArrayList<Sp>();
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			con = DBhelper.getCon();
			ps = con.prepareStatement("select * from sp where spbh in (select spbh from gwc where khbh='"+fkbh+"')");
			rs = ps.executeQuery();
			while (rs.next()) {
				Sp u = new Sp();
				u.setSpbh(rs.getString(1));
				u.setSpmc(rs.getString(2));
				u.setSpsl(rs.getInt(3));
				u.setSpjg(rs.getFloat(4));
				u.setSpxxms(rs.getString(5));
				u.setSjbh(rs.getString(6));
				myl.add(u);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBhelper.myClose(con, ps, rs);
		}
		return myl;
	}

}
