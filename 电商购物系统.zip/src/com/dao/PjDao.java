//package com.dao;
//
//import java.sql.Connection;
//import java.sql.PreparedStatement;
//import java.sql.ResultSet;
//import java.util.ArrayList;
//import java.util.List;
//
//import com.entity.Pj;
//import com.util.DBhelper;
//
//public class PjDao {
//
//	// ��ѯ
//	public List<Pj> selectOne(String fwbh) {
//		List<Pj> mys = new ArrayList<Pj>();
//		Connection con = null;
//		PreparedStatement ps = null;
//		ResultSet rs = null;
//		try {
//			con = DBhelper.getCon();
//			ps = con.prepareStatement("select * from pj where khbh like '%"+fwbh+"%'");
//			rs = ps.executeQuery();
//			while (rs.next()) {
//				Pj u = new Pj();
//				u.setPjbh(rs.getString(1));
//				u.setPjdd(rs.getString(2));
//				u.setPjnr(rs.getString(3));
//				u.setKhbh(rs.getString(4));
//				u.setPjsj(rs.getDate(5));
//				mys.add(u);
//			}
//		} catch (Exception e) {
//			e.printStackTrace();
//		} finally {
//			DBhelper.myClose(con, ps, rs);
//		}
//
//		return mys;
//	}
//
//	// ����
//	public int Add(Pj fw) {
//		int n = 0;
//		Connection con = null;
//		PreparedStatement ps = null;
//		ResultSet rs = null;
//		try {
//			con = DBhelper.getCon();
//			ps = con.prepareStatement(
//					"insert into pj values(?,?,?,?,now())");
//			ps.setString(1, fw.getPjbh());
//			ps.setString(2, fw.getPjdd());
//			ps.setString(3, fw.getPjnr());
//			ps.setString(4, fw.getKhbh());
//			n = ps.executeUpdate();
//		} catch (Exception e) {
//			e.printStackTrace();
//		} finally {
//			DBhelper.myClose(con, ps, rs);
//		}
//
//		return n;
//	}
//
//}
