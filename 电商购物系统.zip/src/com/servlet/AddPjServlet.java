//package com.servlet;
//
//import java.io.IOException;
//import java.io.PrintWriter;
//import java.util.Date;
//
//import javax.servlet.ServletException;
//import javax.servlet.http.HttpServlet;
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//import javax.servlet.http.HttpSession;
//
//import com.dao.DdDao;
//import com.dao.KhDao;
//import com.dao.PjDao;
//import com.entity.Dd;
//import com.entity.Kh;
//import com.entity.Pj;
//
//public class AddPjServlet extends HttpServlet {
//
//	@Override
//	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
//		// TODO Auto-generated method stub
//		doPost(req, resp);
//	}
//
//	@Override
//	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
//		// TODO Auto-generated method stub
//		req.setCharacterEncoding("UTF-8");
//		resp.setContentType("text/html;charset=utf-8");
//		PjDao fddao=new PjDao();
//		PrintWriter out = resp.getWriter();
//		//���session��ֵ���Ա�ǰ��ȡ��
//		String pjdd = req.getParameter("pjdd");
//		String pjnr = req.getParameter("pjnr");
//		String khbh = req.getParameter("khbh");
//		Pj htxx=new Pj(new Date().getTime()+"", pjdd, pjnr, khbh, null);
//		int n = fddao.Add(htxx);
//		if(n>0) {
//			out.print("<script>alert('���ӳɹ���');location.href='addPj.jsp'</script>");
//		}
//		else {
//			out.print("<script>alert('����ʧ�ܣ�')</script>");
//		}
//		
//	}
//
//}
