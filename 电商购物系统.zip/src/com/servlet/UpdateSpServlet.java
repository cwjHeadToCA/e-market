package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.DdDao;
import com.dao.KhDao;
import com.dao.SpDao;
import com.entity.Dd;
import com.entity.Kh;
import com.entity.Sp;

public class UpdateSpServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		req.setCharacterEncoding("UTF-8");
		resp.setContentType("text/html;charset=utf-8");
		SpDao fwdao = new SpDao();
		PrintWriter out = resp.getWriter();
		// ���session��ֵ���Ա�ǰ��ȡ��
		HttpSession session = req.getSession();
		Sp fwxxa = (Sp)session.getAttribute("sp");
		String spmc = req.getParameter("spmc");
		String sjbh = req.getParameter("sjbh");
		String spsl = req.getParameter("spsl");
		String spjg = req.getParameter("spjg");
		String spxxms = req.getParameter("spxxms");
		String img = req.getParameter("img");
		Sp fwxx = new Sp(fwxxa.getSpbh(), spmc, Integer.parseInt(spsl), Float.parseFloat(spjg), spxxms, sjbh,"img/"+img);
		int n = fwdao.update(fwxx);
		if (n > 0) {
			out.print("<script>alert('�޸ĳɹ���');location.href='getAllAdminSp.do'</script>");
		} else {
			out.print("<script>alert('�޸�ʧ�ܣ�')</script>");
		}

	}

}
