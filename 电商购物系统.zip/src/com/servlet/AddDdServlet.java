package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.DdDao;
import com.dao.SpDao;
import com.entity.Dd;
import com.entity.Sp;

public class AddDdServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		req.setCharacterEncoding("UTF-8");
		resp.setContentType("text/html;charset=utf-8");
		DdDao ddxxdao=new DdDao();
		PrintWriter out = resp.getWriter();
		//���session��ֵ���Ա�ǰ��ȡ��
		HttpSession session=req.getSession();
		String khbh = (String)session.getAttribute("khbh");
		String sjbh = req.getParameter("spbh");
		String qzsj = new Date().toLocaleString();
		Sp sp=new SpDao().selectOne(sjbh);
		Dd ddxx=new Dd(new Date().getTime()+"", sjbh, khbh, null, 1, sp.getSpjg());
		int n = ddxxdao.add(ddxx);
		if(n>0) {
			out.print("<script>alert('�����ɹ���');location.href='success.jsp'</script>");
		}
		else {
			out.print("<script>alert('����ʧ�ܣ�');location.href='getAllUserSp.do'</script>");
		}
		
	}

}
