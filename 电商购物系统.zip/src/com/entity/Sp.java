package com.entity;

public class Sp {

	private String spbh;
	private String spmc;
	private int spsl;
	private float spjg;
	private String spxxms;
	private String sjbh;
	private String img;
	
	
	
	

	public Sp(String spbh, String spmc, int spsl, float spjg, String spxxms, String sjbh, String img) {
		super();
		this.spbh = spbh;
		this.spmc = spmc;
		this.spsl = spsl;
		this.spjg = spjg;
		this.spxxms = spxxms;
		this.sjbh = sjbh;
		this.img = img;
	}



	public String getImg() {
		return img;
	}



	public void setImg(String img) {
		this.img = img;
	}



	public String getSpbh() {
		return spbh;
	}



	public void setSpbh(String spbh) {
		this.spbh = spbh;
	}



	public String getSpmc() {
		return spmc;
	}



	public void setSpmc(String spmc) {
		this.spmc = spmc;
	}



	public int getSpsl() {
		return spsl;
	}



	public void setSpsl(int spsl) {
		this.spsl = spsl;
	}



	public float getSpjg() {
		return spjg;
	}



	public void setSpjg(float spjg) {
		this.spjg = spjg;
	}



	public String getSpxxms() {
		return spxxms;
	}



	public void setSpxxms(String spxxms) {
		this.spxxms = spxxms;
	}



	public String getSjbh() {
		return sjbh;
	}



	public void setSjbh(String sjbh) {
		this.sjbh = sjbh;
	}



	public Sp() {
	}
}
