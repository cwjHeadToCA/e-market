package com.entity;

public class Kh {

	private String khbh;
	private String xm;
	private String xb;
	private String nl;
	private String lxfs;
	private String shdz;
	private String mm;
	
	
	
	


	public Kh(String khbh, String xm, String xb, String nl, String lxfs, String shdz, String mm) {
		super();
		this.khbh = khbh;
		this.xm = xm;
		this.xb = xb;
		this.nl = nl;
		this.lxfs = lxfs;
		this.shdz = shdz;
		this.mm = mm;
	}



	public String getMm() {
		return mm;
	}



	public void setMm(String mm) {
		this.mm = mm;
	}



	public String getKhbh() {
		return khbh;
	}



	public void setKhbh(String khbh) {
		this.khbh = khbh;
	}



	public String getXm() {
		return xm;
	}



	public void setXm(String xm) {
		this.xm = xm;
	}



	public String getXb() {
		return xb;
	}



	public void setXb(String xb) {
		this.xb = xb;
	}



	public String getNl() {
		return nl;
	}



	public void setNl(String nl) {
		this.nl = nl;
	}



	public String getLxfs() {
		return lxfs;
	}



	public void setLxfs(String lxfs) {
		this.lxfs = lxfs;
	}



	public String getShdz() {
		return shdz;
	}



	public void setShdz(String shdz) {
		this.shdz = shdz;
	}



	public Kh() {
	}

}
