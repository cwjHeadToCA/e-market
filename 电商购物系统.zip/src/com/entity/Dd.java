package com.entity;

import java.sql.Date;

public class Dd {

	private String ddbh;
	private String sjbh;
	private String khbh;
	private Date gmsj;
	private int gmsl;
	private float gmjg;

	

	public Dd(String ddbh, String sjbh, String khbh, Date gmsj, int gmsl, float gmjg) {
		super();
		this.ddbh = ddbh;
		this.sjbh = sjbh;
		this.khbh = khbh;
		this.gmsj = gmsj;
		this.gmsl = gmsl;
		this.gmjg = gmjg;
	}



	public String getDdbh() {
		return ddbh;
	}



	public void setDdbh(String ddbh) {
		this.ddbh = ddbh;
	}



	public String getSjbh() {
		return sjbh;
	}



	public void setSjbh(String sjbh) {
		this.sjbh = sjbh;
	}



	public String getKhbh() {
		return khbh;
	}



	public void setKhbh(String khbh) {
		this.khbh = khbh;
	}



	public Date getGmsj() {
		return gmsj;
	}



	public void setGmsj(Date gmsj) {
		this.gmsj = gmsj;
	}



	public int getGmsl() {
		return gmsl;
	}



	public void setGmsl(int gmsl) {
		this.gmsl = gmsl;
	}



	public float getGmjg() {
		return gmjg;
	}



	public void setGmjg(float gmjg) {
		this.gmjg = gmjg;
	}



	public Dd() {
	}

}
