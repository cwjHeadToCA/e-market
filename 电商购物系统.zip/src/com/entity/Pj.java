//package com.entity;
//
//import java.sql.Date;
//
//public class Pj {
//
//	private String pjbh;
//	private String pjdd;
//	private String pjnr;
//	private String khbh;
//	private Date pjsj;
//
//	
//
//	public Pj(String pjbh, String pjdd, String pjnr, String khbh, Date pjsj) {
//		super();
//		this.pjbh = pjbh;
//		this.pjdd = pjdd;
//		this.pjnr = pjnr;
//		this.khbh = khbh;
//		this.pjsj = pjsj;
//	}
//
//
//
//	public String getPjbh() {
//		return pjbh;
//	}
//
//
//
//	public void setPjbh(String pjbh) {
//		this.pjbh = pjbh;
//	}
//
//
//
//	public String getPjdd() {
//		return pjdd;
//	}
//
//
//
//	public void setPjdd(String pjdd) {
//		this.pjdd = pjdd;
//	}
//
//
//
//	public String getPjnr() {
//		return pjnr;
//	}
//
//
//
//	public void setPjnr(String pjnr) {
//		this.pjnr = pjnr;
//	}
//
//
//
//	public String getKhbh() {
//		return khbh;
//	}
//
//
//
//	public void setKhbh(String khbh) {
//		this.khbh = khbh;
//	}
//
//
//
//	public Date getPjsj() {
//		return pjsj;
//	}
//
//
//
//	public void setPjsj(Date pjsj) {
//		this.pjsj = pjsj;
//	}
//
//
//
//	public Pj() {}
//
//}
