package com.entity;

import java.sql.Date;

public class Gwc {

	private String spbh;
	private String khbh;
	private Date jgsj;
	private int jgsl;

	

	public Gwc(String spbh, String khbh, Date jgsj, int jgsl) {
		super();
		this.spbh = spbh;
		this.khbh = khbh;
		this.jgsj = jgsj;
		this.jgsl = jgsl;
	}



	public String getSpbh() {
		return spbh;
	}



	public void setSpbh(String spbh) {
		this.spbh = spbh;
	}



	public String getKhbh() {
		return khbh;
	}



	public void setKhbh(String khbh) {
		this.khbh = khbh;
	}



	public Date getJgsj() {
		return jgsj;
	}



	public void setJgsj(Date jgsj) {
		this.jgsj = jgsj;
	}



	public int getJgsl() {
		return jgsl;
	}



	public void setJgsl(int jgsl) {
		this.jgsl = jgsl;
	}



	public Gwc() {
	}

}
