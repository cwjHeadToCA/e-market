package com.entity;

import java.io.Serializable;

public class Sj implements Serializable {

	private String sjbh;
	private String mc;
	private String dz;
	private String fzr;
	private String lxfs;
	private String mm;

	

	public Sj(String sjbh, String mc, String dz, String fzr, String lxfs, String mm) {
		super();
		this.sjbh = sjbh;
		this.mc = mc;
		this.dz = dz;
		this.fzr = fzr;
		this.lxfs = lxfs;
		this.mm = mm;
	}



	public String getSjbh() {
		return sjbh;
	}



	public void setSjbh(String sjbh) {
		this.sjbh = sjbh;
	}



	public String getMc() {
		return mc;
	}



	public void setMc(String mc) {
		this.mc = mc;
	}



	public String getDz() {
		return dz;
	}



	public void setDz(String dz) {
		this.dz = dz;
	}



	public String getFzr() {
		return fzr;
	}



	public void setFzr(String fzr) {
		this.fzr = fzr;
	}



	public String getLxfs() {
		return lxfs;
	}



	public void setLxfs(String lxfs) {
		this.lxfs = lxfs;
	}



	public String getMm() {
		return mm;
	}



	public void setMm(String mm) {
		this.mm = mm;
	}



	public Sj() {
	}

}
